from colorama import *
import datetime

def info(msg):
    current_time = datetime.datetime.now()
    print(f"{current_time.strftime('%H:%M:%S')} INFO: {msg}")

def error(msg):
    current_time = datetime.datetime.now()
    print(f"{current_time.strftime('%H:%M:%S')} ERROR: {msg}")
